# LINGI1341_Projet
Projet de LINGI1341 - Reseaux informatiques
@author: Constantin de Schaetzen and Jean Gillain
@date: October 2018

Pour utiliser les programmes contenus dans le repertoire /src
veuillez specifier au moins 2 arguments, a savoir le nom de domaine ou l'adresse IPV6 du receveur et le numero de port UDP.

L'option -f peut etre mentionnée et a un role different en fonction de la fonction qu'elle complete :

@sender: -f filename.txt permet de lire l'information sur le fichier nommé filename.txt
@receiver: -f filename.txt permet d'ecrire l'information recue sur le fichier nommé filename.txt

Vous pouvez utiliser simplement les fonctions en compilant avec la commande make.

La commande "make clean" permet de supprimer certains .o après utilisation 
